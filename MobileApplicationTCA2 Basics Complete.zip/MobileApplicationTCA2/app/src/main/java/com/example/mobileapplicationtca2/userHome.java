package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class userHome extends AppCompatActivity {

    TextView accountID;
    ListView postList;
    ArrayList<String> listItem;
    ArrayAdapter adapter;
    dbConnectPosts db = new dbConnectPosts(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
        setTitle("User TimeLine");
        accountID = (TextView) findViewById(R.id.accountID);
        postList = (ListView) findViewById(R.id.postList);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        accountID.setText(receivedValue);

        listItem = new ArrayList<>();
        viewData();

        //String text = postList.getItemAtPosition()
    }

    public void openMyAccount(View view){
        Intent openMyAccount = new Intent(this, myAccount.class);
        openMyAccount.putExtra("UserAccount", accountID.getText().toString());
        startActivity(openMyAccount);
    }

    public void openCreatePost(View view){
        Intent openCreatePost = new Intent(this, createNewPosts.class);
        openCreatePost.putExtra("UserAccount", accountID.getText().toString());
        startActivity(openCreatePost);
    }

    public void viewData(){
        Cursor cursor = db.viewPosts();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Posts Found",Toast.LENGTH_SHORT).show();
        }
        else {
            while (cursor.moveToNext()){
                String record = "UserName: " + cursor.getString(1) + "\nPost Date: " + cursor.getString(3)
                        + "\nPost: " + cursor.getString(2) + "\n";
                listItem.add(record);
            }

            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItem);
            postList.setAdapter(adapter);
        }

    }

    //reference https://www.youtube.com/watch?v=N-gHIJShz1I&ab_channel=KODDev

}