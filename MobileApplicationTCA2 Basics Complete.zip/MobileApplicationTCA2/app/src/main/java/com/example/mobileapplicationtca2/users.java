package com.example.mobileapplicationtca2;

public class users {
    private int id;
    private String firstname;
    private String surname;
    private String email;
    private String dateOfBirth;
    private String password;
    private String date;

    public users(int id, String firstname, String surname,
                 String email, String dateOfBirth, String password, String date){
        this.id = id;
        this.firstname = firstname;
        this.surname = surname;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.password = password;
        this.date = date;
    }
    public users(String firstname, String surname,
                 String email, String dateOfBirth, String password, String date){
        this.firstname = firstname;
        this.surname = surname;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.password = password;
        this.date = date;
    }

    public users(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id){
        this.id = id;
    }
    public String getFirstname(){
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}

