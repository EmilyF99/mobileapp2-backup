package com.example.mobileapplicationtca2;

public class posts {
    private int postID;
    private String userID;
    private String postContent;
    private String postTime;

    public posts(int postID, String userID, String postContent, String postTime){
        this.postID = postID;
        this.userID = userID;
        this.postContent = postContent;
        this.postTime = postTime;
    }

    public posts(String userID, String postContent, String postTime){
        this.userID = userID;
        this.postContent = postContent;
        this.postTime = postTime;
    }

    public int getPostID() {
        return postID;
    }

    public void setPostID(int postID) {
        this.postID = postID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPostContent() {
        return postContent;
    }

    public void setPostContent(String postContent) {
        this.postContent = postContent;
    }

    public String getPostTime() {
        return postTime;
    }

    public void setPostTime(String postTime) {
        this.postTime = postTime;
    }
}
