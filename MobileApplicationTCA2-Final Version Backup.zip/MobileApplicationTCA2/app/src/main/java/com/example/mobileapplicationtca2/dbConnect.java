package com.example.mobileapplicationtca2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
/**
 * File Name: dbConnect.java
 * Purpose: Database Method file for the Users Table
 * Activity Order: db.0
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class dbConnect extends SQLiteOpenHelper {

    //defining key variables for the Users Table
    private static final String dbName = "timeLineAppManage";
    private static final String dbTableUsers = "users";
    private static int dbVersion = 1;

    private static String ID = "id";
    private static String firstname = "firstname";
    private static String surname = "surname";
    private static String email = "email";
    private static String dateOfBirth = "dateOfBirth";
    private static String password = "password";
    private static String dateCreated = "dateCreated";
    private static String date = "date";


    public dbConnect(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //Create UsersTable with columns, ID, Firstname, Surname, Email, Date of Birth, Password, Date and Date Created
        String query = "create table " + dbTableUsers + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + firstname + " TEXT, " + surname + " TEXT, "
                + email + " TEXT, " + dateOfBirth + " TEXT, " + password + " TEXT, " + date + " TEXT, " + dateCreated + " Text)";

        sqLiteDatabase.execSQL(query);
    }

    /*When the table is updated it is dropped and cleared.
    Then Create method is called to recreate the updated database */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + dbTableUsers);
        onCreate(sqLiteDatabase);
    }

    //takes a user object to utilise getters and setters
    public void addUser(users user) {
        //fetches the database so it can be overwritten
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //Assigning new values for the database
        values.put(firstname, user.getFirstname());
        values.put(surname, user.getSurname());
        values.put(email, user.getEmail());
        values.put(dateOfBirth, user.getDateOfBirth());
        values.put(password, user.getPassword());
        values.put(date, user.getDate());
        values.put(dateCreated, user.getCreatedDate());

        //inserting the above values into the database
        db.insert(dbTableUsers, null, values);
    }

    //allows the user to update their records
    //takes a user object to utilise getters and setters
    //takes a String for the wear clause
    public void updateUser(users user, String id) {
        //fetches the database so it can be overwritten
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //Assigning new values for the database
        values.put(firstname, user.getFirstname());
        values.put(surname, user.getSurname());
        values.put(email, user.getEmail());
        values.put(dateOfBirth, user.getDateOfBirth());
        values.put(password, user.getPassword());
        values.put(date, user.getDate());

        //inserts the above values into the row where the passed ID matches
        db.update(dbTableUsers, values, "id=?", new String[]{id});
    }

    //Used in the userLogin activity
    //Compares the username and password inputted to the database records
    public boolean checkUsernamePassword(users users) {

        //fetches the database in readable form so it is not accidentally overwritten
        SQLiteDatabase db = this.getReadableDatabase();

        //selects only records where the username and email match what is inputted
        String query = "SELECT * from " + dbTableUsers + " where " + email + "=? AND " + password + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{users.getEmail(), users.getPassword()});

        //record is found
        //record is not found
        if (cursor.moveToFirst()) return true;
        else return false;

    }

    //Un-used method, if properly implemented, would prevent user from registering using the same email address
    /*
    public boolean verifyEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * from " + dbTableUsers + " where " + email + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{email});
        if (!(cursor.moveToFirst())) {
            return true;
        } else {
            return false;
        }
    }*/

    //Used to retrieve a single user record
    public Cursor fetchUser(String accountID) {
        //fetches the database in readable form so it is not accidentally overwritten
        SQLiteDatabase db = this.getReadableDatabase();
        //Selects a user that has a email that matches the accountID passed to it
        String query = "SELECT * from " + dbTableUsers + " where " + email + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{accountID});
        return cursor;

    }

    //Used to retrieve all users in the user table
    //Used for the admin menu to view all accounts
    public Cursor fetchUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from " + dbTableUsers;
        Cursor cursor = db.rawQuery(query, null);
        return cursor;
    }

    //Deletes a single user record
    //Delete is decided by matching email address to the userID passed by the user
    public boolean deleteUser(String userID) {
        SQLiteDatabase db = this.getWritableDatabase();
        int endResult = db.delete(dbTableUsers, email + "=?", new String[]{userID});

        //record deleted
        //record not deleted
        if (endResult > 0) return true;
        else return false;
    }

}