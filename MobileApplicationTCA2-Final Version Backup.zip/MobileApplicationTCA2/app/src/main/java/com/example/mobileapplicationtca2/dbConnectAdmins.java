package com.example.mobileapplicationtca2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
/**
 * File Name: dbConnectAdmins.java
 * Purpose: Database Method file for the Admins Table
 * Activity Order: db.1
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class dbConnectAdmins extends SQLiteOpenHelper {

    //defining key variables for the Users Table
    private static final String dbName = "timeLineAppManage";
    private static final String dbTableAdmins = "admins";
    private static int dbVersion = 1;

    private static String ID = "id";
    private static String email = "email";
    private static String password = "password";

    public dbConnectAdmins(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //Creates Admin table with columns, ID, email and password
        String query = "create table " + dbTableAdmins + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+ email + " TEXT, " + password + " TEXT)";
        sqLiteDatabase.execSQL(query);
    }

    /*When the table is updated it is dropped and cleared.
    Then Create method is called to recreate the updated database */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + dbTableAdmins);
        onCreate(sqLiteDatabase);
    }

    //Used in the userLogin activity
    //Compares the username and password inputted to the database records
    public boolean checkUsernamePassword(admins admins){
        //fetches the database in readable form so it is not accidentally overwritten
        SQLiteDatabase db = this.getReadableDatabase();

        //selects only records where the username and email match what is inputted
        String query = "SELECT * from " + dbTableAdmins + " where " + email + "=? AND " + password + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{admins.getEmail(), admins.getPassword()});

        /*record is found
        record is not found*/
        if(cursor.moveToFirst()) return true;
        else return false;

    }
}
