package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
/**
 * File Name: createNewPosts.java
 * Purpose: Allows a user create a new post that will be displayed on the TimeLine
 * Activity Order: U.4
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

/**References for this Activity (Full References in Report)
 * Nick (2017) - Stack Overflow Post used to Understand how to get the date
 * Coding Pursuits (2021) - YouTube video used to understand passing data to different activities
 */
public class createNewPosts extends AppCompatActivity {

    //XML Object List
    EditText createPostIn;
    TextView userID, firstnameIn, surnameIn;
    Button createPost;

    //database connection to posts table
    dbConnectPosts db = new dbConnectPosts(this);
    //database connection to users table
    dbConnect usersdb = new dbConnect(this);

    //Method that is used to create a date
    /*Assigns a date format, then gets instance from device clock,
     * then returns it as a timestamp */
    public String createDate(){
        DateFormat sortable = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        String timestamp = sortable.format(now);
        return timestamp;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_posts);
        //Set Title
        setTitle("Create Post");

        //linking XML Objects
        createPostIn = findViewById(R.id.userPostInput);
        userID = findViewById(R.id.accountIDCreatePosts);
        firstnameIn = findViewById(R.id.firstnameCreatePosts);
        surnameIn = findViewById(R.id.surnameNewPosts);
        createPost = findViewById(R.id.submitPostButton);

        //receiving the value passed by the last activity when this one was opened,
        //used to get ID which is used to set account ID
        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        userID.setText(receivedValue);

        //passes userID to method in order to get the users first and surname
        getNames(receivedValue);

        //when Create Post Button click
        createPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //gets values in editText fields and sets them to the values of Strings
                String accountID = userID.getText().toString();
                String postContent = createPostIn.getText().toString();
                String firstname = firstnameIn.getText().toString();
                String surname = surnameIn.getText().toString();

                //if any fields are empty then a toast message is displayed asking the user for all fields
                if(TextUtils.isEmpty(postContent)) {
                    Toast.makeText(createNewPosts.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                }
                //if all fields are filled
                else{
                    //creates a date at time of post creation
                    String date = createDate();
                    //creates a new post objects
                    posts p1 = new posts(accountID, postContent,date,firstname, surname);
                    //takes object and passes it to the add post method to create a new post
                    db.addPost(p1);
                    //Toast message to let the user know their post has been created
                    Toast.makeText(createNewPosts.this, "Post Created", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    //uses ID to find user account in the users database
    //uses a cursor to set first and surname based on record found using ID
    public void getNames(String accountID){
        Cursor cursor = usersdb.fetchUser(accountID);
        while (cursor.moveToNext()){
            String firstnameRecord = cursor.getString(1);
            String surnameRecord = cursor.getString(2);

            firstnameIn.setText(firstnameRecord);
            surnameIn.setText(surnameRecord);

        }

    }

}