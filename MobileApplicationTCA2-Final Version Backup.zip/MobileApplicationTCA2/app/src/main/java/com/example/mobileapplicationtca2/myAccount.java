package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
/**
 * File Name: myAccount.java
 * Purpose: Allows a user to update their account details and view the last time their account was
 *          edited, also allows viewing of data account was created.
 * Activity Order: U.3
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

/**References for this Activity (Full References in Report)
 * Coding Pursuits (2021) - YouTube video used to understand passing data to different activities
 * Luke Vo (2011) - Stack Overflow post used for refreshing the activity window
 * Nick (2017) - Stack Overflow Post used to Understand how to get the date
 */
public class myAccount extends AppCompatActivity {

    //XML Object List
    EditText firstname, surname, email, dob, password;
    TextView lastEdited, userID, dateCreated;
    Button saveChanges;

    //database connection to users table
    dbConnect db = new dbConnect(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);
        //sets title
        setTitle("My Account");

        //linking XML Objects
        lastEdited = findViewById(R.id.myAccountDateLastUpdated);
        userID = findViewById(R.id.myAccountUserID);
        firstname = findViewById(R.id.myAccountFirstName);
        surname = findViewById(R.id.myAccountSurname);
        email = findViewById(R.id.myAccountEmail);
        dob = findViewById(R.id.myAccountDateOfBirth);
        password = findViewById(R.id.myAccountPassword);
        saveChanges = findViewById(R.id.submitAccountChangesButton);
        dateCreated = findViewById(R.id.dateAccoutnCreated);

        //receiving the value passed by the last activity when this one was opened,
        //used to get ID which is used to set account ID
        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        String accountID = receivedValue;

        //call to viewData method
        viewData(accountID);

        //when save button is clicked method is called
        saveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //gets values in editText fields and sets them to the values of Strings
                String selectUserID = userID.getText().toString();
                String updateFirstNameEdited = firstname.getText().toString();
                String updateSurnameEdited = surname.getText().toString();
                String updateEmailEdited = email.getText().toString();
                String updateDobEdited = dob.getText().toString();
                String updatePassword = password.getText().toString();

                //If any fields are empty a toast message is created asking the user to fill all fields
                if(TextUtils.isEmpty(updateFirstNameEdited) || TextUtils.isEmpty(updateSurnameEdited) || TextUtils.isEmpty(updateEmailEdited)
                        || TextUtils.isEmpty(updateDobEdited) || TextUtils.isEmpty(updatePassword)) {

                    Toast.makeText(myAccount.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                }
                //if all fields are present
                else{
                    //date created at time of update.
                    String date = createDate();
                    //creates a new user object that will be passed to the database
                    users u1 = new users(updateFirstNameEdited, updateSurnameEdited, updateEmailEdited,
                            updateDobEdited, updatePassword, date, date);
                    //passes user object to the update function
                    db.updateUser(u1, selectUserID);
                }
                /*when button pressed and changes made the activity ends and is
                * restarted, this is the changes just made are visible to the user*/
                finish();
                overridePendingTransition(0, 0);
                startActivity(getIntent());
                overridePendingTransition(0, 0);

            }
        });
    }
    //Method that is used to create a date
    /*Assigns a date format, then gets instance from device clock,
     * then returns it as a timestamp */
    public String createDate(){
        DateFormat sortable = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        String timestamp = sortable.format(now);
        return timestamp;
    }

    //used to fetch the users account on activity creation
    private void viewData(String accountID){
        Cursor cursor = db.fetchUser(accountID);

        //if no record found, then toast message displayed
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No data to show", Toast.LENGTH_SHORT).show();
        }
        else {
            //while there is a record
            while (cursor.moveToNext()){
                //sets all the text fields based off cursor
                userID.setText(cursor.getString(0));
                firstname.setText(cursor.getString(1));
                surname.setText(cursor.getString(2));
                email.setText(cursor.getString(3));
                dob.setText(cursor.getString(4));
                password.setText(cursor.getString(5));
                lastEdited.setText(cursor.getString(6));
                dateCreated.setText(cursor.getString(7));
            }
        }
    }

}
