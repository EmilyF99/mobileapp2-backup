package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
/**
 * File Name: userDeletePost.java
 * Purpose: The user can view all their own posts on a spinner, they can select one and delete its
 *          contents
 * Activity Order: U.7
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

/**References for this Activity (Full References in Report)
 * Coding Pursuits (2021) - YouTube video used to understand passing data to different activities
 * Nick (2017) - Stack Overflow Post used to Understand how to get the date
 * KOD Dev (2018) - Tutorial used for adding SQL Records to a Spinner
 * Aman Singh (2016) - Used for reloading the activity after a button click
 */
public class userDeletePost extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    //XML Object List
    Spinner userDeletePostSpinner;
    TextView userID;
    Button userDeletePostButton;

    //database connection to posts table
    dbConnectPosts db = new dbConnectPosts(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_delete_post);
        //sets title
        setTitle("Delete a Post");

        //linking XML Objects
        userDeletePostSpinner = findViewById(R.id.userDeletePostSpinner);
        userDeletePostButton = findViewById(R.id.userEditPostButton);
        userID = findViewById(R.id.userAccountIDDeletePost);

        //receiving the value passed by the last activity when this one was opened,
        //used to get ID which is used to set account ID
        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        userID.setText(receivedValue);

        //sets a listener so that when the item on the spinner is clicked it is selected
        userDeletePostSpinner.setOnItemSelectedListener(this);
        //calls method so all posts are set into a spinner
        viewPosts();

        //method called when delete button is clicked
        userDeletePostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //gets post content and sets it to String
                String postContent = userDeletePostSpinner.getSelectedItem().toString();
                //boolean that passes post to delete Post method
                //if true then deletes post
                boolean result = db.deletePost(postContent);

                //if true, lets the user know post is deleted via toast
                if(result){
                    Toast.makeText(userDeletePost.this, "Post Deleted", Toast.LENGTH_SHORT).show();
                    //closes the activity and reopens it, this makes it update.
                    //allows the users changes to be seen straight away
                    finish();
                    overridePendingTransition(0, 0);
                    startActivity(getIntent());
                    overridePendingTransition(0, 0);
                }
            }
        });
    }
    //Auto generated
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) { }

    //Auto generated
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) { }

    //called on create, used to fetch values for spinner
    public void viewPosts(){
        //fetch accountID and pass it to viewMyPosts method
        String accountID = userID.getText().toString();
        Cursor cursor = db.viewMyPosts(accountID);
        //Array list to store posts in
        List<String> posts = new ArrayList<>();

        //if no posts found toast message displayed
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Posts Found", Toast.LENGTH_SHORT).show();
        }
        else {
            //while there is a record
            while(cursor.moveToNext()){
                //get second column and add it to the list
                String record = cursor.getString(2);
                posts.add(record);
            }
        }
        //sets listview layout and contents
        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item,posts);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userDeletePostSpinner.setAdapter(ad);
    }
}