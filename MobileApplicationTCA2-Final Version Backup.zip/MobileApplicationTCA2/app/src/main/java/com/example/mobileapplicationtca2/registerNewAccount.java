package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * File Name: registerNewAccount.java
 * Purpose: Creating New Accounts
 * Activity Order: 2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

/**References for this Activity (Full References in Report)
 * Nick (2017) - Stack Overflow Post used to Understand how to get the date
 */
public class registerNewAccount extends AppCompatActivity {

    //List of Objects used in XML
    EditText firstNameIn, surnameIn, emailIn, dateOfBirthIn, passwordIn;
    Button createAccount;

    //Database Connection
    //Connects to the Users Table
    dbConnect db = new dbConnect(this);

    //Method that is used to create a date
    /*Assigns a date format, then gets instance from device clock,
    * then returns it as a timestamp */
    public String createDate(){
        DateFormat sortable = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        String timestamp = sortable.format(now);
        return timestamp;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_new_account);
        //Set Title
        setTitle("Create New Account");

        //linking to XML
        firstNameIn = findViewById(R.id.firstNameBox);
        surnameIn = findViewById(R.id.surnameBox);
        emailIn = findViewById(R.id.emailBox);
        dateOfBirthIn = findViewById(R.id.dateOfBirthBox);
        passwordIn = findViewById(R.id.passwordBox);
        createAccount = findViewById(R.id.createAccountButton);

        //When the createAccount button is clicked this method is called.
        createAccount.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                //Gets the fields inputted by the user and passes them to Strings
                String firstname = firstNameIn.getText().toString();
                String surname = surnameIn.getText().toString();
                String email = emailIn.getText().toString();
                String dob = dateOfBirthIn.getText().toString();
                String password = passwordIn.getText().toString();

                /*If any of the fields are empty or null then the record is not created and
                * a toast message is displayed requesting the user to input all fields*/
                if(TextUtils.isEmpty(firstname) || TextUtils.isEmpty(surname) || TextUtils.isEmpty(email)
                        || TextUtils.isEmpty(dob) || TextUtils.isEmpty(password)) {

                    Toast.makeText(registerNewAccount.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                }
                else{
                    /*Calls the create date method, called here to ensure that
                    * the date created is created at the same time as the account is created.*/
                   String date = createDate();

                   //defines a new user record and passes all the columns into it
                   users u1 = new users(firstname, surname, email, dob, password, date, date);
                   //passes the record into the addUser method in the database class
                   db.addUser(u1);
                   Toast.makeText(registerNewAccount.this, "Account Created", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



}