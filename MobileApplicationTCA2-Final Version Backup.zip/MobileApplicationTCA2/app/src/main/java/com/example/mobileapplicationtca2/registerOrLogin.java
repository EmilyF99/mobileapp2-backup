package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * File Name: registerOrLogin.java
 * Purpose: Allows a User to choose between login options
 * Activity Order: 1
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

public class registerOrLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_or_login);
        //Sets Title
        setTitle("Register Or Login");
    }

    //Starts the Create Account Activity
    public void createAccountClicked(View view){
        Intent createAccount = new Intent(this, registerNewAccount.class);
        startActivity(createAccount);
    }

    //Starts the User Login Activity
    public void userLoginClicked(View view){
        Intent userLogin = new Intent(this, userLogin.class);
        startActivity(userLogin);
    }

    //Starts the Admin Login Activity
    public void adminLoginClicked(View view){
        Intent adminLogin = new Intent(this, adminLogin.class);
        startActivity(adminLogin);
    }

}