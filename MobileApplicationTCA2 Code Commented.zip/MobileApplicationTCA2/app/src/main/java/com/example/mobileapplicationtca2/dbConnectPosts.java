package com.example.mobileapplicationtca2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

/**
 * File Name: dbConnectPosts.java
 * Purpose: Database Method file for the Posts Table
 * Activity Order: db.2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class dbConnectPosts extends SQLiteOpenHelper {

    //defining key variables for the Posts Table
    private static String dbName = "timeLineAppManage";
    private static String dbTablePosts = "posts";
    private static int dbVersion = 1;

    private static String postID = "postID";
    private static String userID = "userID";
    private static String postContent = "postContent";
    private static String postTime = "postTime";
    private static String firstname = "firstname";
    private static String surname = "surname";

    public dbConnectPosts(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //Create Posts Table with Columns, postID, userID, postContent,postTime, Firstname, Surname
        String postQuery = "create table " + dbTablePosts + "(" + postID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+ userID + " TEXT, " + postContent + " TEXT, "
                + postTime + " TEXT, " + firstname + " TEXT, " + surname +" TEXT)";

        sqLiteDatabase.execSQL(postQuery);
    }

    /*When the table is updated it is dropped and cleared.
   Then Create method is called to recreate the updated database */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + dbTablePosts);
        onCreate(sqLiteDatabase);
    }

    //takes a user object to utilise getters and setters
    public void addPost(posts post){
        //fetches the database so it can be overwritten
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //Assigning new values for the database
        values.put(userID, post.getUserID());
        values.put(postContent, post.getPostContent());
        values.put(postTime, post.getPostTime());
        values.put(firstname, post.getFirstname());
        values.put(surname, post.getSurname());

        //inserting the above values into the database
        db.insert(dbTablePosts, null, values);
    }

    //used to find all the posts stored, used on the main timeline
    public Cursor viewPosts(){
        //fetches the database so it can be read
        SQLiteDatabase db = this.getReadableDatabase();
        //selects all from the posts table and retrieves it in descending order so newest record is shown first
        String query = "Select * from " + dbTablePosts + " ORDER BY " +  postTime   + " DESC ";
        Cursor cursor = db.rawQuery(query, null);
        return cursor;
    }

    //used to find just the posts created by a single user
    //uses an ID sent by the user to select posts by one user, sorts in descending order, newest record is shown first
    public Cursor viewMyPosts(String accountID){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * from " + dbTablePosts +  " where " + userID + "=?" + " ORDER BY " +  postTime   + " DESC ";
        Cursor cursor = db.rawQuery(query, new String[]{accountID});
        return cursor;
    }


    //used to delete every post created by a user, used in combination with the delete user method.
    public boolean deleteAllUserPosts(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        //deletes a record where the email by the user matches a row in the database
        int endResult = db.delete(dbTablePosts,  userID + "=?", new String[]{email});
        if(endResult > 0){
            //record deleted
            return true;
        }
        else {
            //record not deleted
            return false;
        }
    }

    //method called to delete a specific post
    //finds post match by comparing teh posts content submitted by the user and the postContent row
    public boolean deletePost(String post){
        SQLiteDatabase db = this.getWritableDatabase();
        int endResult = db.delete(dbTablePosts,  postContent+ "=?", new String[]{post});
        if(endResult > 0){
            //record deleted
            return true;
        }
        else {
            //record not deleted
            return false;
        }
    }

    //Allows the user to edit the contents of a post
    /*changes the postContent to match what the user has now inputted
    Other fields from that record are not passed as only the post content needs be updated
    post object needs to be passed in order to use teh getters and setters, ID is passed to make sure
    right post is updated*/
    public void editPost(posts post, String id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(postContent, post.getPostContent());
        db.update(dbTablePosts,values, "postID=?", new String[]{id});
    }
}


