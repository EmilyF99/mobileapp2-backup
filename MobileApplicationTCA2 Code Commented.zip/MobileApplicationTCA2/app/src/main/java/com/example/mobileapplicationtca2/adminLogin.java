package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
/**
 * File Name: adminLogin.java
 * Purpose: Allows the admin to login and access the admin side of the app
 * Activity Order: A.1
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class adminLogin extends AppCompatActivity {

    //XML Object List
    EditText email, password;
    Button adminLogin;

    //database connection to admin table
    dbConnectAdmins db = new dbConnectAdmins(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        //sets activity title
        setTitle("Admin Login");

        //linking XML Objects
        email = (EditText) findViewById(R.id.adminEmail);
        password = (EditText) findViewById(R.id.adminPassword);
        adminLogin = (Button) findViewById(R.id.loginButton);

        //method called when admin login button clicked
        adminLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //gets the value inputted by the user
                String emailIn = email.getText().toString();
                String passwordIn = password.getText().toString();

                //if any values are empty then a toast message is displayed asking the user to
                //fill out all fields
                if (TextUtils.isEmpty(emailIn) || TextUtils.isEmpty(passwordIn)) {
                    Toast.makeText(adminLogin.this, "All Fields Required", Toast.LENGTH_SHORT).show();
                }
                //if all fields are filled
                else {
                    //admin object created
                    admins a1 = new admins(emailIn, passwordIn);
                    //checks values of object against those in the database table
                    boolean result = db.checkUsernamePassword(a1);
                    //if there is a match open the admin home menu
                    if (result) {
                        openAdminHome();
                    }
                    //if there is no match then toast to tell user that no account was found
                    else {
                        Toast.makeText(adminLogin.this, "Login Not Found", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    //opens adminHome activity and passes the users email address to the next activity
    public void openAdminHome(){
        Intent openAdminHome = new Intent(this, adminHub.class);
        openAdminHome.putExtra("AdminAccount", email.getText().toString());
        startActivity(openAdminHome);
    }
}