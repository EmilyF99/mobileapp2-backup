package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
/**
 * File Name: adminHub.java
 * Purpose: Allows the admin to view all the accounts and save the users accounts to a file
 * Activity Order: A.2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class adminHub extends AppCompatActivity {

    //XML Object List
    TextView accountID;
    ListView userList;
    Button saveUsersToFile;

    //Array list and adapter used to list user accounts in the list view
    ArrayList<String> usersItems;
    ArrayAdapter adapter;

    //database connection to user table
    dbConnect db = new dbConnect(this);

    //defining the name for the file used for saving user accounts
    String FileName = "userAccount.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_hub);

        //sets activity title
        setTitle("Admin Home");

        //linking XML Objects
        accountID = (TextView) findViewById(R.id.adminAccountID);
        userList = (ListView) findViewById(R.id.userList);
        saveUsersToFile = (Button) findViewById(R.id.saveUsersToFileButton);

        //receiving the value passed by the last activity when this one was opened,
        //used to get ID which is used to set account ID
        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("AdminAccount");
        accountID.setText(receivedValue);

        usersItems = new ArrayList<>();

        //called on create to populate listview with users account
        viewUsers();

        //if file does not exist then the create file method is used
        try {
            createFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //fetches all the user accounts
    public void viewUsers(){
        //defines a cursor and fetches all the user accounts in the database
        Cursor cursor = db.fetchUsers();

        //if no records are found then a toast message is displayed telling the user
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Users Found", Toast.LENGTH_SHORT);
        }
        //if record is found
        else {
            //while there is a record then values from the record are passed into a string
            //this record is then added to a list
            while(cursor.moveToNext()){
                String record = "User ID: " + cursor.getString(0) + "\nFirst Name: " + cursor.getString(1)
                        + "\nSurname: " + cursor.getString(2) + "\nEmail: " + cursor.getString(3)
                        + "\nDate Of Birth: " + cursor.getString(4) + "\nDate Last Updated: " + cursor.getString(6)
                        + "\n";
                usersItems.add(record);
            }
        }
        //sets the layout and content of the listview
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, usersItems);
        userList.setAdapter(adapter);
    }

    //when delete user button is clicked the method is called to open the next activity
    public void openDeleteUser(View view){
        Intent openDeleteUser = new Intent(this, deleteUser.class);
        startActivity(openDeleteUser);
    }

    //used to create the file needed to save users
    //gets the directory of the device
    //defines a file with the directory and the filename defined earlier
    //creates a file with the above detail
    //sends a toast to the user to show them the filepath of the file created
    public void createFile() throws IOException {
        File dir = getFilesDir();
        File file = new File(dir, FileName);
        file.createNewFile();
        Toast.makeText(this, "File Created: " + file, Toast.LENGTH_SHORT).show();
    }

    //When the save to file button is clicked this method is called.
    public void saveValuesToFile(View view){
        //original file is cleared, this is so duplicate records are not saved
        clearFile();

        //defines a cursor and fetches all the user accounts in the database
        Cursor cursor = db.fetchUsers();

        //if no records are found then a toast message is displayed telling the user
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Users To Save", Toast.LENGTH_SHORT).show();
        }
        //if record is found
        else {
            //while there is a record then values from the record are passed into a string
            //this record is then added to a list
            while(cursor.moveToNext()){
                String record = "User ID: " + cursor.getString(0) + "\nFirst Name: " + cursor.getString(1)
                        + "\nSurname: " + cursor.getString(2) + "\nEmail: " + cursor.getString(3)
                        + "\nDate Of Birth: " + cursor.getString(4) + "\nDate Last Updated: " + cursor.getString(6)
                        + "\n";

                FileOutputStream fos = null;
                try {
                    //sets the file to append so information is added to the file
                    //writes the contents of cursor to the file
                    //displays a toast so user knows that users are saved.
                    fos = view.getContext().openFileOutput(FileName, MODE_APPEND);
                    fos.write(record.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Users Saved", Toast.LENGTH_SHORT).show();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (fos != null) {
                        try {
                            fos.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }

    //called on button click to remove old file
    public void clearFile() {
        //Set to empty string, overwrites current users file
        String reset = " ";
        FileOutputStream fos = null;

        try {
            //mode private so that file is overwritten rather than amended.
            fos = openFileOutput(FileName, MODE_PRIVATE);
            fos.write(reset.getBytes(StandardCharsets.UTF_8));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
    }
}