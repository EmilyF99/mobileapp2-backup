package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
/**
 * File Name: myTimeline.java
 * Purpose: The user can view all their own posts, from here they can navigate to editing
 *          and deleting posts
 * Activity Order: U.5
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class myTimeline extends AppCompatActivity {

    //XML Object List
    TextView accountID, firstname, surname;
    ListView myPostList;

    //Array list used to get posts and display them
    ArrayList<String> myPostlistItem;
    ArrayAdapter adapter;

    //used to create a timed auto update
    private BroadcastReceiver updateMyPostList;

    //database connection to posts table
    dbConnectPosts db = new dbConnectPosts(this);
    //database connection to users table
    dbConnect dbUsers = new dbConnect(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_timeline);
        //set Title
        setTitle("My TimeLine");

        //linking XML Objects
        accountID = (TextView) findViewById(R.id.accountIDMyTimeline);
        firstname = (TextView) findViewById(R.id.firstnameMyTimeLine);
        surname = (TextView) findViewById(R.id.surnameMyTimeLine);
        myPostList = (ListView) findViewById(R.id.userList);

        //receiving the value passed by the last activity when this one was opened,
        //used to get ID which is used to set account ID
        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        accountID.setText(receivedValue);

        myPostlistItem = new ArrayList<>();
        //Method call to set all the posts on the timeline when activity is opened
        viewData();
        //ID is passed into this function to get the users first and surname
        getNames(receivedValue);
    }

    //finds rows in the post table and sets them onto an Array Adapter to display them within a list view
    public void viewData() {
        String UserID = accountID.getText().toString();
        //cursor that points to records
        Cursor cursor = db.viewMyPosts(UserID);

        //No posts in the table toast message
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Posts Found", Toast.LENGTH_SHORT).show();
        } else {
            //while the cursor finds a record
            while (cursor.moveToNext()) {
                //string made up of all columns in post database
                //cursor.getString(i) is used to get specific column
                //then added onto the array list
                String record = "UserName: " + cursor.getString(4) + " " + cursor.getString(5) + "\nPost Date: " + cursor.getString(3)
                        + "\nPost: " + cursor.getString(2) + "\n";
                myPostlistItem.add(record);
            }
            //setting adapter layout and content
            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, myPostlistItem);
            myPostList.setAdapter(adapter);
        }

    }
    //method that refreshes the activity after a tick
    //used to fetch any new posts
    private void startUpdater() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        updateMyPostList = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                /*after tick time elapses then the post list is cleared,
                 * post list is fetched again afterwards so new posts are displayed*/
                myPostlistItem.clear();
                viewData();
            }
        };
        registerReceiver(updateMyPostList, intentFilter);
    }

    //on window resume restart updater
    protected void onResume() {
        super.onResume();
        startUpdater();
    }

    //on window pause stop updater, to save on resources
    protected void onPause() {
        super.onPause();
        unregisterReceiver(updateMyPostList);
    }

    //opens delete post when button is clicked
    //passes userID to the delete post activity
    public void openUserDeletePost(View view) {
        Intent userDeletePost = new Intent(this, userDeletePost.class);
        userDeletePost.putExtra("UserAccount", accountID.getText().toString());
        startActivity(userDeletePost);
    }

    //opens edit post when button is clicked
    //passes userID to the edit post activity
    public void openUserEditPost(View view) {
        Intent userEditPost = new Intent(this, userEditPost.class);
        userEditPost.putExtra("UserAccount", accountID.getText().toString());
        startActivity(userEditPost);
    }

    //used to fetch first name and surname, used as welcome back message
    public void getNames(String accountID) {
        Cursor cursor = dbUsers.fetchUser(accountID);
        while (cursor.moveToNext()) {
            //while the cursor has found a record, set value in column 1 as firstname and value in column 2 as surname
            String firstnameRecord = cursor.getString(1);
            String surnameRecord = cursor.getString(2);

            firstname.setText(firstnameRecord);
            surname.setText(surnameRecord);
        }
    }
}
