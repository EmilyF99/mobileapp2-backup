package com.example.mobileapplicationtca2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.SimpleCursorAdapter;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class dbConnectPosts extends SQLiteOpenHelper {

    private static String dbName = "timeLineAppManage";
    private static String dbTablePosts = "posts";

    private static String postID = "postID";
    private static String userID = "userID";
    private static String postContent = "postContent";
    private static String postTime = "postTime";
    private static int dbVersion = 1;

    public dbConnectPosts(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String postQuery = "create table " + dbTablePosts + "(" + postID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+ userID + " TEXT, " + postContent + " TEXT, "
                + postTime + " TEXT)";

        sqLiteDatabase.execSQL(postQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + dbTablePosts);
        onCreate(sqLiteDatabase);
    }

    public void addPost(posts post){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(userID, post.getUserID());
        values.put(postContent, post.getPostContent());
        values.put(postTime, post.getPostTime());
        db.insert(dbTablePosts, null, values);
    }

    public Cursor viewPosts(){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * from " + dbTablePosts + " ORDER BY " +  postTime   + " DESC ";
        Cursor cursor = db.rawQuery(query, null);

        return cursor;
    }

    public Cursor viewMyPosts(String accountID){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * from " + dbTablePosts +  " where " + userID + "=?" + " ORDER BY " +  postTime   + " DESC ";
        Cursor cursor = db.rawQuery(query, new String[]{accountID});
        return cursor;
    }

    public boolean deleteAllUserPosts(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        int endResult = db.delete(dbTablePosts,  userID + "=?", new String[]{email});
        if(endResult > 0){
            return true;
        }
        else {
            return false;
        }
    }
}
//reference https://www.youtube.com/watch?v=N-gHIJShz1I&ab_channel=KODDev