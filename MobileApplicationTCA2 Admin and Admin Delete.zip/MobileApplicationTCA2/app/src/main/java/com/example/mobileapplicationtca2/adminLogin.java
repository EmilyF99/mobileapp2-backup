package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class adminLogin extends AppCompatActivity {

    EditText email, password;
    Button adminLogin;
    dbConnectAdmins db = new dbConnectAdmins(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        setTitle("Admin Login");
        email = (EditText) findViewById(R.id.adminEmail);
        password = (EditText) findViewById(R.id.adminPassword);
        adminLogin = (Button) findViewById(R.id.loginButton);

        adminLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailIn = email.getText().toString();
                String passwordIn = password.getText().toString();

                if (TextUtils.isEmpty(emailIn) || TextUtils.isEmpty(passwordIn)) {
                    Toast.makeText(adminLogin.this, "All Fields Required", Toast.LENGTH_SHORT).show();
                } else {
                    admins a1 = new admins(emailIn, passwordIn);
                    boolean result = db.checkUsernamePassword(a1);
                    if (result) {
                        openAdminHome();
                    } else {
                        Toast.makeText(adminLogin.this, "Login Not Found", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void openAdminHome(){
        Intent openAdminHome = new Intent(this, adminHub.class);
        openAdminHome.putExtra("AdminAccount", email.getText().toString());
        startActivity(openAdminHome);
    }
}