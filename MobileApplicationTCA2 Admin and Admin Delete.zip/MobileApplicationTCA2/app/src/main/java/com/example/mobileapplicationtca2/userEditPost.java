package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class userEditPost extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_edit_post);
    }
}