package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;
import java.util.List;

public class deleteUser extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner userSpinner;
    Button deleteUserButton;

    dbConnect db = new dbConnect(this);
    dbConnectPosts dbPosts = new dbConnectPosts(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_user);
        userSpinner = (Spinner) findViewById(R.id.userSpinner);
        deleteUserButton = (Button) findViewById(R.id.deleteUserButt);
        setTitle("Delete User");
        userSpinner.setOnItemSelectedListener(this);
        viewUsers();

        deleteUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userID = userSpinner.getSelectedItem().toString();
                boolean result = db.deleteUser(userID);
                boolean postResults = dbPosts.deleteAllUserPosts(userID);
                if(result){
                    Toast.makeText(deleteUser.this, "Record Deleted", Toast.LENGTH_SHORT).show();
                }
                if(postResults){
                    Toast.makeText(deleteUser.this, "All Posts By User Deleted", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void viewUsers(){
        Cursor cursor = db.fetchUsers();
        List<String> users = new ArrayList<String>();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Users Found", Toast.LENGTH_SHORT);
        }
        else {
            while(cursor.moveToNext()){
                String record = cursor.getString(3);
                users.add(record);
            }
        }
        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item,users);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userSpinner.setAdapter(ad);
    }

}