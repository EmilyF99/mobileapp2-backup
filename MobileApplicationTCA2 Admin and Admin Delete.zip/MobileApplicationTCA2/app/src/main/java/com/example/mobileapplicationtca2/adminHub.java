package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class adminHub extends AppCompatActivity {

    TextView accountID;
    ListView userList;
    Button saveUsersToFile;

    ArrayList<String> usersItems;
    ArrayAdapter adapter;

    dbConnect db = new dbConnect(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_hub);
        setTitle("Admin Home");

        accountID = (TextView) findViewById(R.id.adminAccountID);
        userList = (ListView) findViewById(R.id.userList);
        saveUsersToFile = (Button) findViewById(R.id.saveUsersToFileButton);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("AdminAccount");
        accountID.setText(receivedValue);

        usersItems = new ArrayList<>();
        viewUsers();
    }

    public void viewUsers(){
        Cursor cursor = db.fetchUsers();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Users Found", Toast.LENGTH_SHORT);
        }
        else {
            while(cursor.moveToNext()){
                String record = "User ID: " + cursor.getString(0) + "\nFirst Name: " + cursor.getString(1)
                        + "\nSurname: " + cursor.getString(2) + "\nEmail: " + cursor.getString(3)
                        + "\nDate Of Birth: " + cursor.getString(4) + "\nDate Last Updated: " + cursor.getString(6)
                        + "\n";
                usersItems.add(record);
            }
        }
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, usersItems);
        userList.setAdapter(adapter);
    }

    public void openDeleteUser(View view){
        Intent openDeleteUser = new Intent(this, deleteUser.class);
        startActivity(openDeleteUser);
    }
}