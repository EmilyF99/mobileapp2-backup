package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class userDeletePost extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_delete_post);
    }
}