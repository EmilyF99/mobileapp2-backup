package com.example.mobileapplicationtca2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.session.PlaybackState;

import androidx.annotation.Nullable;

public class dbConnect extends SQLiteOpenHelper {

    private static String dbName = "timeLineAppManage";
    private static String dbTableUsers = "users";

    private static String ID = "id";
    private static String firstname = "firstname";
    private static String surname = "surname";
    private static String email = "email";
    private static String dateOfBirth = "dateOfBirth";
    private static String password = "password";
    private static String date = "date";
    private static int dbVersion = 1;

    public dbConnect(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //create table_users (id_primary_autoincrement, firstname_text, surname_text, email_text, dateOfBirth_text,password_text);
        String query = "create table " + dbTableUsers + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+ firstname + " TEXT, " + surname + " TEXT, "
                + email + " TEXT, " + dateOfBirth + " TEXT, " + password + " TEXT, " + date + " Text)";

        sqLiteDatabase.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + dbTableUsers);
        onCreate(sqLiteDatabase);
    }

    public void addUser(users user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(firstname, user.getFirstname());
        values.put(surname, user.getSurname());
        values.put(email, user.getEmail());
        values.put(dateOfBirth, user.getDateOfBirth());
        values.put(password, user.getPassword());
        values.put(date, user.getDate());
        db.insert(dbTableUsers, null, values);
    }

    public void updateUser(users user, String id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(firstname, user.getFirstname());
        values.put(surname, user.getSurname());
        values.put(email, user.getEmail());
        values.put(dateOfBirth, user.getDateOfBirth());
        values.put(password, user.getPassword());
        values.put(date, user.getDate());
        db.update(dbTableUsers,values, "id=?", new String[]{id});
    }


    public boolean checkUsernamePassword(users users){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * from " + dbTableUsers + " where " + email + "=? AND " + password + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{users.getEmail(), users.getPassword()});
        if(cursor.moveToFirst()){
            return true;
        }
        else {
            return false;
        }
    }

    public boolean verifyEmail(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * from " + dbTableUsers + " where " + email + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{email});
        if(cursor.moveToFirst()){
            return true;
        }
        else {
            return false;
        }
    }

    public Cursor fetchUser(String accountID){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * from " + dbTableUsers + " where " + email + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{accountID});
        return cursor;

    }

    public Cursor fetchUsers(){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from " + dbTableUsers;
        Cursor cursor = db.rawQuery(query, null);
        return cursor;
    }

    public boolean deleteUser(String userID){
        SQLiteDatabase db = this.getWritableDatabase();
        int endResult = db.delete(dbTableUsers, email + "=?", new String[]{userID});
        if(endResult > 0){
            return true;
        }
        else {
            return false;
        }
    }


}

//reference
//https://stackoverflow.com/questions/45126614/how-to-add-date-of-creation-of-record-in-sqlite-table-in-android-and-later-displ