package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class userHome extends AppCompatActivity {

    TextView accountID;
    ListView postList;
    ArrayList<String> listItem;
    ArrayAdapter adapter;
    private BroadcastReceiver updatePostList;
    dbConnectPosts db = new dbConnectPosts(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
        setTitle("User TimeLine");
        accountID = (TextView) findViewById(R.id.accountID);
        postList = (ListView) findViewById(R.id.userList);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        accountID.setText(receivedValue);

        listItem = new ArrayList<>();
        viewData();

    }

    public void openMyAccount(View view){
        Intent openMyAccount = new Intent(this, myAccount.class);
        openMyAccount.putExtra("UserAccount", accountID.getText().toString());
        startActivity(openMyAccount);
    }

    public void openCreatePost(View view){
        Intent openCreatePost = new Intent(this, createNewPosts.class);
        openCreatePost.putExtra("UserAccount", accountID.getText().toString());
        startActivity(openCreatePost);
    }

    public void openMyTimeLine(View view){
        Intent openMyTimeLine = new Intent(this, myTimeline.class);
        openMyTimeLine.putExtra("UserAccount", accountID.getText().toString());
        startActivity(openMyTimeLine);
    }

    public void viewData(){
        Cursor cursor = db.viewPosts();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Posts Found",Toast.LENGTH_SHORT).show();
        }
        else {
            while (cursor.moveToNext()){
                String record = "UserName: " + cursor.getString(1) + "\nPost Date: " + cursor.getString(3)
                        + "\nPost: " + cursor.getString(2) + "\n";
                listItem.add(record);
            }

            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItem);
            postList.setAdapter(adapter);
        }

    }

    private void startUpdater(){
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        updatePostList = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                listItem.clear();
                viewData();
            }
        };

        registerReceiver(updatePostList, intentFilter);
    }

    protected void onResume() {
        super.onResume();
        startUpdater();
    }

    protected void onPause(){
        super.onPause();
        unregisterReceiver(updatePostList);
    }

    //reference https://www.youtube.com/watch?v=N-gHIJShz1I&ab_channel=KODDev
    //https://www.youtube.com/watch?v=hXWVaAyXkoQ&ab_channel=CodinginFlow
}