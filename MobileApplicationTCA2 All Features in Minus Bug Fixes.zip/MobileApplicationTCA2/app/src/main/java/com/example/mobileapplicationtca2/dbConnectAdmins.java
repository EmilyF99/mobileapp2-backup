package com.example.mobileapplicationtca2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbConnectAdmins extends SQLiteOpenHelper {

    private static String dbName = "timeLineAppManage";
    private static String dbTableAdmins = "admins";

    private static String ID = "id";
    private static String email = "email";
    private static String password = "password";

    private static int dbVersion = 1;

    public dbConnectAdmins(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "create table " + dbTableAdmins + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+ email + " TEXT, " + password + " TEXT)";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + dbTableAdmins);
        onCreate(sqLiteDatabase);
    }

    public boolean checkUsernamePassword(admins admins){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * from " + dbTableAdmins + " where " + email + "=? AND " + password + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{admins.getEmail(), admins.getPassword()});
        if(cursor.moveToFirst()){
            return true;
        }
        else {
            return false;
        }
    }
}
