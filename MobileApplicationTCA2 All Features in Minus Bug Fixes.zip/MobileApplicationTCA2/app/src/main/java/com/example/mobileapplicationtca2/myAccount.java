package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class myAccount extends AppCompatActivity {

    EditText firstname, surname, email, dob, password;
    TextView lastEdited, userID, dateCreated;
    Button saveChanges;

    dbConnect db = new dbConnect(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);
        setTitle("My Account");

        lastEdited = (TextView) findViewById(R.id.myAccountDateLastUpdated);
        userID = (TextView) findViewById(R.id.myAccountUserID);
        firstname = (EditText) findViewById(R.id.myAccountFirstName);
        surname = (EditText) findViewById(R.id.myAccountSurname);
        email = (EditText) findViewById(R.id.myAccountEmail);
        dob = (EditText) findViewById(R.id.myAccountDateOfBirth);
        password = (EditText) findViewById(R.id.myAccountPassword);
        saveChanges = (Button) findViewById(R.id.submitAccountChangesButton);
        dateCreated = (TextView) findViewById(R.id.dateAccoutnCreated);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        String accountID = receivedValue;

        viewData(accountID);

        saveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectUserID = userID.getText().toString();
                String updateFirstNameEdited = firstname.getText().toString();
                String updateSurnameEdited = surname.getText().toString();
                String updateEmailEdited = email.getText().toString();
                String updateDobEdited = dob.getText().toString();
                String updatePassword = dob.getText().toString();

                if(TextUtils.isEmpty(updateFirstNameEdited) || TextUtils.isEmpty(updateSurnameEdited) || TextUtils.isEmpty(updateEmailEdited)
                        || TextUtils.isEmpty(updateDobEdited) || TextUtils.isEmpty(updatePassword)) {

                    Toast.makeText(myAccount.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                }
                else{
                    String date = createDate();
                    users u1 = new users(updateFirstNameEdited, updateSurnameEdited, updateEmailEdited,
                            updateDobEdited, updatePassword, date, date);
                    db.updateUser(u1, selectUserID);
                }

            }
        });
    }

    public String createDate(){
        DateFormat sortable = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        String timestamp = sortable.format(now);
        return timestamp;
    }

    private void viewData(String accountID){
        Cursor cursor = db.fetchUser(accountID);

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No data to show", Toast.LENGTH_SHORT);
        }
        else {
            while (cursor.moveToNext()){
                userID.setText(cursor.getString(0));
                firstname.setText(cursor.getString(1));
                surname.setText(cursor.getString(2));
                email.setText(cursor.getString(3));
                dob.setText(cursor.getString(4));
                password.setText(cursor.getString(5));
                lastEdited.setText(cursor.getString(6));
                dateCreated.setText(cursor.getString(7));
            };
        }
    }

}

//add date function so date can be updated