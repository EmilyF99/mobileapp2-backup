package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ButtonBarLayout;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class userEditPost extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner userEditPostSpinner;
    TextView userID, postID, postTime;
    EditText postContent;
    Button userEditPostButton;

    dbConnectPosts db = new dbConnectPosts(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_edit_post);
        setTitle("Edit Post");
        userEditPostSpinner = (Spinner) findViewById(R.id.userEditPostSpinner);
        userEditPostButton = (Button) findViewById(R.id.EditPostButton);
        userID = (TextView) findViewById(R.id.userAccountIDEditPost);
        postContent = (EditText) findViewById(R.id.editPostContentBox);
        postID = (TextView) findViewById(R.id.PostIDEditPost);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        userID.setText(receivedValue);

        userEditPostSpinner.setOnItemSelectedListener(this);
        viewPosts();


        userEditPostSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String postContentString = userEditPostSpinner.getSelectedItem().toString();

                String[] postIDSplit = postContentString.split(",");
                String postIDStringSplit = postIDSplit[0];
                String postContentSplit = postIDSplit[1];
                postContent.setText(postContentSplit);
                postID.setText(postIDStringSplit);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        userEditPostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String postIDString = postID.getText().toString();
                String updatedPostString = postContent.getText().toString();
                String userIDString = userID.getText().toString();

                if (TextUtils.isEmpty(updatedPostString)) {
                    Toast.makeText(userEditPost.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                } else {
                    posts p1 = new posts(userIDString, updatedPostString);
                    db.editPost(p1, postIDString);
                    Toast.makeText(userEditPost.this, "Post Edited", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void viewPosts() {
        String accountID = userID.getText().toString();
        Cursor cursor = db.fetchPosts(accountID);
        List<String> posts = new ArrayList<String>();

        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Posts Found", Toast.LENGTH_SHORT);
        } else {
            while (cursor.moveToNext()) {
                String postIDRecord = cursor.getString(0);
                String record = cursor.getString(2);
                String combinedRecord = postIDRecord + "," + record;
                posts.add(combinedRecord);
            }
        }
        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item, posts);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userEditPostSpinner.setAdapter(ad);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

}