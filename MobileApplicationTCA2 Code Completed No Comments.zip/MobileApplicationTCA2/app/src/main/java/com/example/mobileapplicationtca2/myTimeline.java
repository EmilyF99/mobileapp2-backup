package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class myTimeline extends AppCompatActivity {

    TextView accountID, firstname, surname;
    ListView myPostList;
    ArrayList<String> myPostlistItem;
    ArrayAdapter adapter;
    private BroadcastReceiver updateMyPostList;
    dbConnectPosts db = new dbConnectPosts(this);
    dbConnect dbUsers = new dbConnect(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_timeline);
        setTitle("My TimeLine");
        accountID = (TextView) findViewById(R.id.accountIDMyTimeline);
        firstname = (TextView) findViewById(R.id.firstnameMyTimeLine);
        surname = (TextView) findViewById(R.id.surnameMyTimeLine);
        myPostList = (ListView) findViewById(R.id.userList);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        accountID.setText(receivedValue);

        myPostlistItem = new ArrayList<>();
        viewData();
        getNames(receivedValue);
    }

    public void viewData() {
        String UserID = accountID.getText().toString();
        Cursor cursor = db.viewMyPosts(UserID);

        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Posts Found", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                String record = "UserName: " + cursor.getString(4) + " " + cursor.getString(5) + "\nPost Date: " + cursor.getString(3)
                        + "\nPost: " + cursor.getString(2) + "\n";
                myPostlistItem.add(record);
            }

            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, myPostlistItem);
            myPostList.setAdapter(adapter);
        }

    }

    private void startUpdater() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        updateMyPostList = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                myPostlistItem.clear();
                viewData();
            }
        };

        registerReceiver(updateMyPostList, intentFilter);
    }

    protected void onResume() {
        super.onResume();
        startUpdater();
    }

    protected void onPause() {
        super.onPause();
        unregisterReceiver(updateMyPostList);
    }

    public void openUserDeletePost(View view) {
        Intent userDeletePost = new Intent(this, userDeletePost.class);
        userDeletePost.putExtra("UserAccount", accountID.getText().toString());
        startActivity(userDeletePost);
    }

    public void openUserEditPost(View view) {
        Intent userEditPost = new Intent(this, userEditPost.class);
        userEditPost.putExtra("UserAccount", accountID.getText().toString());
        startActivity(userEditPost);
    }

    public void getNames(String accountID) {
        Cursor cursor = dbUsers.fetchUser(accountID);
        while (cursor.moveToNext()) {
            String firstnameRecord = cursor.getString(1);
            String surnameRecord = cursor.getString(2);

            firstname.setText(firstnameRecord);
            surname.setText(surnameRecord);

        }
    }
}

//reference https://stackoverflow.com/questions/3053761/reload-activity-in-android