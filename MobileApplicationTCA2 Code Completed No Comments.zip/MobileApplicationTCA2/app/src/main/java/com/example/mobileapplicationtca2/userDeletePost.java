package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class userDeletePost extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    Spinner userDeletePostSpinner;
    TextView userID;
    Button userDeletePostButton;

    dbConnectPosts db = new dbConnectPosts(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_delete_post);
        setTitle("Delete a Post");
        userDeletePostSpinner = (Spinner) findViewById(R.id.userDeletePostSpinner);
        userDeletePostButton = (Button) findViewById(R.id.userEditPostButton);
        userID = (TextView)findViewById(R.id.userAccountIDDeletePost);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        userID.setText(receivedValue);

        userDeletePostSpinner.setOnItemSelectedListener(this);
        viewPosts();


        userDeletePostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String postContent = userDeletePostSpinner.getSelectedItem().toString();
                boolean result = db.deletePost(postContent);
                if(result){
                    Toast.makeText(userDeletePost.this, "Post Deleted", Toast.LENGTH_SHORT).show();
                    finish();
                    overridePendingTransition(0, 0);
                    startActivity(getIntent());
                    overridePendingTransition(0, 0);
                }

            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void viewPosts(){
        String accountID = userID.getText().toString();
        Cursor cursor = db.fetchPosts(accountID);
        List<String> posts = new ArrayList<String>();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Posts Found", Toast.LENGTH_SHORT);
        }
        else {
            while(cursor.moveToNext()){
                String record = cursor.getString(2);
                posts.add(record);
            }
        }
        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item,posts);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userDeletePostSpinner.setAdapter(ad);
    }
}