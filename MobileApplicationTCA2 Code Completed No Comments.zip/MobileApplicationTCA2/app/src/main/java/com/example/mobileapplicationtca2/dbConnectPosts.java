package com.example.mobileapplicationtca2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbConnectPosts extends SQLiteOpenHelper {

    private static String dbName = "timeLineAppManage";
    private static String dbTablePosts = "posts";

    private static String postID = "postID";
    private static String userID = "userID";
    private static String postContent = "postContent";
    private static String postTime = "postTime";
    private static String firstname = "firstname";
    private static String surname = "surname";
    private static int dbVersion = 1;

    public dbConnectPosts(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String postQuery = "create table " + dbTablePosts + "(" + postID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+ userID + " TEXT, " + postContent + " TEXT, "
                + postTime + " TEXT, " + firstname + " TEXT, " + surname +" TEXT)";

        sqLiteDatabase.execSQL(postQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + dbTablePosts);
        onCreate(sqLiteDatabase);
    }

    public void addPost(posts post){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(userID, post.getUserID());
        values.put(postContent, post.getPostContent());
        values.put(postTime, post.getPostTime());
        values.put(firstname, post.getFirstname());
        values.put(surname, post.getSurname());
        db.insert(dbTablePosts, null, values);
    }

    public Cursor viewPosts(){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * from " + dbTablePosts + " ORDER BY " +  postTime   + " DESC ";
        Cursor cursor = db.rawQuery(query, null);

        return cursor;
    }

    public Cursor viewMyPosts(String accountID){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * from " + dbTablePosts +  " where " + userID + "=?" + " ORDER BY " +  postTime   + " DESC ";
        Cursor cursor = db.rawQuery(query, new String[]{accountID});
        return cursor;
    }

    public boolean deleteAllUserPosts(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        int endResult = db.delete(dbTablePosts,  userID + "=?", new String[]{email});
        if(endResult > 0){
            return true;
        }
        else {
            return false;
        }
    }

    public Cursor fetchPosts(String accountID){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = " SELECT * from " + dbTablePosts + " where " + userID + "=?";
        Cursor cursor = db.rawQuery(query,new String[]{accountID});
        return cursor;
    }

    public boolean deletePost(String post){
        SQLiteDatabase db = this.getWritableDatabase();
        int endResult = db.delete(dbTablePosts,  postContent+ "=?", new String[]{post});
        if(endResult > 0){
            return true;
        }
        else {
            return false;
        }
    }


    public void editPost(posts post, String id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(postContent, post.getPostContent());
        db.update(dbTablePosts,values, "postID=?", new String[]{id});
    }
}
//reference https://www.youtube.com/watch?v=N-gHIJShz1I&ab_channel=KODDev
