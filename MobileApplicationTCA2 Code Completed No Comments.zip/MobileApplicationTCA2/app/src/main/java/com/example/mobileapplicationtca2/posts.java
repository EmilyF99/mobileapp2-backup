package com.example.mobileapplicationtca2;

public class posts {
    private int postID;
    private String userID;
    private String postContent;
    private String postTime;
    private String firstname;
    private String surname;

    public posts(int postID, String userID, String postContent, String postTime, String firstname, String surname){
        this.postID = postID;
        this.userID = userID;
        this.postContent = postContent;
        this.postTime = postTime;
        this.firstname = firstname;
        this.surname = surname;
    }

    public posts(String userID, String postContent, String postTime, String firstname, String surname){
        this.userID = userID;
        this.postContent = postContent;
        this.postTime = postTime;
        this.firstname = firstname;
        this.surname = surname;
    }


    public posts(String userIDString, String updatedPostString) {
        this.userID = userIDString;
        this.postContent = updatedPostString;
    }

    public int getPostID() {
        return postID;
    }

    public void setPostID(int postID) {
        this.postID = postID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPostContent() {
        return postContent;
    }

    public void setPostContent(String postContent) {
        this.postContent = postContent;
    }

    public String getPostTime() {
        return postTime;
    }

    public void setPostTime(String postTime) {
        this.postTime = postTime;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }
}
