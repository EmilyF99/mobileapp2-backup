package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class createNewPosts extends AppCompatActivity {

    EditText createPostIn;
    TextView userID, firstnameIn, surnameIn;
    Button createPost;
    dbConnectPosts db = new dbConnectPosts(this);
    dbConnect usersdb = new dbConnect(this);

    public String createDate(){
        DateFormat sortable = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        String timestamp = sortable.format(now);
        return timestamp;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_posts);
        setTitle("Create Post");
        createPostIn = (EditText) findViewById(R.id.userPostInput);
        userID = (TextView) findViewById(R.id.accountIDCreatePosts);
        firstnameIn = (TextView) findViewById(R.id.firstnameCreatePosts);
        surnameIn = (TextView) findViewById(R.id.surnameNewPosts);
        createPost = (Button) findViewById(R.id.submitPostButton);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        userID.setText(receivedValue);
        getNames(receivedValue);

        createPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String accountID = userID.getText().toString();
                String postContent = createPostIn.getText().toString();
                String firstname = firstnameIn.getText().toString();
                String surname = surnameIn.getText().toString();

                if(TextUtils.isEmpty(postContent)) {
                    Toast.makeText(createNewPosts.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                }
                else{
                    String date = createDate();
                    posts p1 = new posts(accountID, postContent,date,firstname, surname);
                    db.addPost(p1);
                    Toast.makeText(createNewPosts.this, "Post Created", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
    public void getNames(String accountID){
        Cursor cursor = usersdb.fetchUser(accountID);
        while (cursor.moveToNext()){
            String firstnameRecord = cursor.getString(1);
            String surnameRecord = cursor.getString(2);

            firstnameIn.setText(firstnameRecord);
            surnameIn.setText(surnameRecord);

        }

    }

}