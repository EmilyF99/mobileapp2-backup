package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class userLogin extends AppCompatActivity {

    EditText email, password;
    Button login;
    dbConnect db = new dbConnect(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        setTitle("User Login");
        email = (EditText) findViewById(R.id.userEmail);
        password = (EditText) findViewById(R.id.userPassword);
        login = (Button) findViewById(R.id.LoginButton);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailIn = email.getText().toString();
                String passwordIn = password.getText().toString();

                if(TextUtils.isEmpty(emailIn) || TextUtils.isEmpty(passwordIn)){
                    Toast.makeText(userLogin.this, "All Fields Required", Toast.LENGTH_SHORT).show();
                }
                else{
                   users u1 = new users(emailIn, passwordIn);
                   boolean result = db.checkUsernamePassword(u1);
                   if (result){
                       openHome();
                   }else{
                       Toast.makeText(userLogin.this, "Login Not Found", Toast.LENGTH_SHORT).show();
                   }
                }
            }
        });

    }
    public void openHome(){
        Intent userHome = new Intent(this, userHome.class);
        userHome.putExtra("UserAccount", email.getText().toString());
        startActivity(userHome);
    }
}