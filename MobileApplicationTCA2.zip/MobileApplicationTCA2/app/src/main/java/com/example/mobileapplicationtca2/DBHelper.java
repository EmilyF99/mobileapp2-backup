package com.example.mobileapplicationtca2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelper extends SQLiteOpenHelper {

    public static final String DBNAME = "login.db";
    public DBHelper(Context context) {
        super(context, "login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table users(userID TEXT primary key, firstname TEXT, surname TEXT, email TEXT, dateOfBith TEXT, Password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists users");
    }
}

//Reference
//https://www.youtube.com/watch?v=yJ02XTKiuAc&ab_channel=CodingWithMe
