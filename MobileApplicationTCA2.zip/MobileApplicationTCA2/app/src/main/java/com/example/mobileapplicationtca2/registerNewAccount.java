package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * File Name: registerNewAccount.java
 * Purpose: Creating New Accounts
 * Activity Order: 2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class registerNewAccount extends AppCompatActivity {

    EditText firstNameIn, surnameIn, emailIn, dateOfBirthIn, passwordIn, verifyPasswordIn;
    Button createAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_new_account);
        setTitle("Create New Account");
        firstNameIn = (EditText) findViewById(R.id.firstNameBox);
        surnameIn = (EditText) findViewById(R.id.surnameBox);
        emailIn = (EditText) findViewById(R.id.emailBox);
        dateOfBirthIn = (EditText) findViewById(R.id.dateOfBirthBox);
        passwordIn = (EditText) findViewById(R.id.passwordBox);
        verifyPasswordIn = (EditText) findViewById(R.id.verifyPasswordBox);
        createAccount = (Button) findViewById(R.id.createAccountButton);

        createAccount.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

            }
        });
    }

    //when submit is clicked check all have something in before posting to database
    //if all filled then call password verify activity to check both match
    //if matched and verified then push all on submit and create timestamp for account creation


}