package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
/**
 * File Name: deleteUser.java
 * Purpose: Allows the admin to view all the accounts and save the users accounts to a file
 * Activity Order: A.3
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

/**References for this Activity (Full References in Report)
 * KOD Dev (2018) - Tutorial used for adding SQL Records to a Spinner
 * Luke Vo (2011) - Stack Overflow post used for refreshing the activity window
 * Aman Singh (2016) - Used for reloading the activity after a button click
 */
public class deleteUser extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    //XML Object List
    Spinner userSpinner;
    Button deleteUserButton;

    //database connection to user table
    dbConnect db = new dbConnect(this);

    //database connection to post table
    dbConnectPosts dbPosts = new dbConnectPosts(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //sets activity title
        setTitle("Delete User");
        setContentView(R.layout.activity_delete_user);

        //linking XML Objects
        userSpinner = findViewById(R.id.userSpinner);
        deleteUserButton = findViewById(R.id.deleteUserButt);

        //sets selected listener so spinner can be clicked (Not used in this class)
        userSpinner.setOnItemSelectedListener(this);

        //calls viewUsers method in create so, populates spinner on create
        viewUsers();

        //when delete button clicked method is called
        deleteUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //fetches userID from the spinner
                String userID = userSpinner.getSelectedItem().toString();
                //passes userID inside deleteUser method and assigns the result as boolean
                boolean result = db.deleteUser(userID);
                //passes userID inside deletePosts method and assigns the result as boolean
                boolean postResults = dbPosts.deleteAllUserPosts(userID);
                //if result = true then the user has been deleted and a toast displays this back to the user
                if(result){
                    Toast.makeText(deleteUser.this, "Record Deleted", Toast.LENGTH_SHORT).show();
                }
                //if result = true then all the posts by the user have also been deleted and a toast is displayed to the user.
                if(postResults){
                    Toast.makeText(deleteUser.this, "All Posts By User Deleted", Toast.LENGTH_SHORT).show();
                }
                //closes the activity and reopens it, this makes it update.
                //allows the users changes to be seen straight away
                finish();
                overridePendingTransition(0, 0);
                startActivity(getIntent());
                overridePendingTransition(0, 0);
            }
        });
    }

    //Auto Generated
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) { }

    //Auto Generated
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) { }

    //fetches all the users and sets them to spinner
    public void viewUsers(){
        //assigns a cursor and calls fetchUsers methods
        Cursor cursor = db.fetchUsers();
        List<String> users = new ArrayList<String>();

        //if no record found then toast message is displayed to let the user know that no record was found
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Users Found", Toast.LENGTH_SHORT);
        }
        //if record found
        else {
            while(cursor.moveToNext()){
                //get value in column three and add it to the record, email column
                String record = cursor.getString(3);
                users.add(record);
            }
        }
        //sets content and layout of spinner
        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item,users);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userSpinner.setAdapter(ad);
    }
}