package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

/**
 * File Name: MainActivity.java
 * Purpose: Generates a Splash Screen for when the app opens
 * Activity Order: 0
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class MainActivity extends AppCompatActivity {

    //Timer for Splash Screen
    final int SPLASHTIMER = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Hides the top bar so the splash screen can take up the fullscreen
        getSupportActionBar().hide();

        //handler is used as a timer for the Splash Screen
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent registerOrLogin = new Intent(MainActivity.this,
                        registerOrLogin.class);
                startActivity(registerOrLogin);
                //ends this activity after the next one starts to free up resources
                finish();
            }
        }, SPLASHTIMER);
    }
}