package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
/**
 * File Name: userLogin.java
 * Purpose: Allows a Standard User to Login to the app.
 * Activity Order: U.1
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class userLogin extends AppCompatActivity {

    //XML Object List
    EditText email, password;
    Button login;

    //Datebase connection to user table
    dbConnect db = new dbConnect(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        //set Activity title
        setTitle("User Login");

        //linking XML Objects
        email = findViewById(R.id.userEmail);
        password = findViewById(R.id.userPassword);
        login = findViewById(R.id.LoginButton);

        //Method called when login button clicked
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Gets values inputted by the user
                String emailIn = email.getText().toString();
                String passwordIn = password.getText().toString();

                //If either username or password box is empty then a toast message is displayed asking for all fields
                if(TextUtils.isEmpty(emailIn) || TextUtils.isEmpty(passwordIn)){
                    Toast.makeText(userLogin.this, "All Fields Required", Toast.LENGTH_SHORT).show();
                }
                //if all fields are present, else statement called
                else{
                    //new user object with fields needed inside
                   users u1 = new users(emailIn, passwordIn);
                   //passes values to check method
                   boolean result = db.checkUsernamePassword(u1);
                   //if matching account is found the user home activity is open
                   if (result){
                       openHome();
                   }else{
                       //if not account is found then toast message displayed to the user.
                       Toast.makeText(userLogin.this, "Login Not Found", Toast.LENGTH_SHORT).show();
                   }
                }
            }
        });

    }
    //method that opens the next activity
    public void openHome(){
        Intent userHome = new Intent(this, userHome.class);
        //passes the userID to the next activity
        userHome.putExtra("UserAccount", email.getText().toString());
        startActivity(userHome);
    }
}