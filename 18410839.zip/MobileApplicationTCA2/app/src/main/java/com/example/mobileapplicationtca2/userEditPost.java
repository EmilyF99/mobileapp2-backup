package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
/**
 * File Name: userEditPost.java
 * Purpose: The user can view all their own posts on a spinner, they can select one and edit its
 *          contents
 * Activity Order: U.6
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

/**References for this Activity (Full References in Report)
 * Coding Pursuits (2021) - YouTube video used to understand passing data to different activities
 * KOD Dev (2018) - Tutorial used for adding SQL Records to a Spinner
 * Aman Singh (2016) - Used for reloading the activity after a button click
 */
public class userEditPost extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    //XML Object List
    Spinner userEditPostSpinner;
    TextView userID, postID;
    EditText postContent;
    Button userEditPostButton;

    //database connection to posts table
    dbConnectPosts db = new dbConnectPosts(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_edit_post);
        //sets Title
        setTitle("Edit Post");

        //linking XML Objects
        userEditPostSpinner = findViewById(R.id.userEditPostSpinner);
        userEditPostButton = findViewById(R.id.EditPostButton);
        userID = findViewById(R.id.userAccountIDEditPost);
        postContent = findViewById(R.id.editPostContentBox);
        postID = findViewById(R.id.PostIDEditPost);

        //receiving the value passed by the last activity when this one was opened,
        //used to get ID which is used to set account ID
        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        userID.setText(receivedValue);

        //sets a listener so that when the item on the spinner is clicked it is selected
        userEditPostSpinner.setOnItemSelectedListener(this);

        //calls method so all posts are set into a spinner
        viewPosts();

        //when item in the spinner is clicked
        userEditPostSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                //Gets value from spinner and turns into a string
                String postContentString = userEditPostSpinner.getSelectedItem().toString();

                //splits the spinner into separate strings where there is a comma
                String[] postIDSplit = postContentString.split(",");

                //Where the first split is, that value is used as the post ID number
                String postIDStringSplit = postIDSplit[0];
                //Where the second split is, that value is used as the post content
                String postContentSplit = postIDSplit[1];
                postContent.setText(postContentSplit);
                postID.setText(postIDStringSplit);
            }

            //Auto Created as part of Spinner
            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });

        //Method called when edit post button clicked
        userEditPostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //gets values currently stored in activity fields
                String postIDString = postID.getText().toString();
                String updatedPostString = postContent.getText().toString();
                String userIDString = userID.getText().toString();

                //if any fields are empty then a toast message is displayed
                if (TextUtils.isEmpty(updatedPostString)) {
                    Toast.makeText(userEditPost.this, "All Fields Are Required", Toast.LENGTH_SHORT).show();
                }
                //if all fields are filled
                else {
                    //new post object is created and values passed for use in the database
                    posts p1 = new posts(userIDString, updatedPostString);
                    //new object is passed to the edit post method
                    db.editPost(p1, postIDString);
                    //toast to let the user know that the post has been edited
                    Toast.makeText(userEditPost.this, "Post Edited", Toast.LENGTH_SHORT).show();
                }
                //closes the activity and reopens it to act as a refresh so user changes are shown straight away
                finish();
                overridePendingTransition(0, 0);
                startActivity(getIntent());
                overridePendingTransition(0, 0);
            }
        });
    }

    //method to view all posts and set them onto a spinner
    public void viewPosts() {
        //ID fetched in order to find record
        String accountID = userID.getText().toString();

        Cursor cursor = db.viewMyPosts(accountID);
        List<String> posts = new ArrayList<>();

        //if no database records found, toast message
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Posts Found", Toast.LENGTH_SHORT).show();
        } else {
            //if record found, cursor is set to strings and combined to make spinner fields
            while (cursor.moveToNext()) {
                String postIDRecord = cursor.getString(0);
                String record = cursor.getString(2);
                String combinedRecord = postIDRecord + "," + record;
                posts.add(combinedRecord);
            }
        }
        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item, posts);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userEditPostSpinner.setAdapter(ad);
    }

    //Auto Created
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) { }

    //Auto Created
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) { }
}