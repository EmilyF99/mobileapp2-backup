package com.example.mobileapplicationtca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
/**
 * File Name: userHome.java
 * Purpose: Allows a User to see all posts, gives options to navigate to their
 *          timeline, create posts, and view their account
 * Activity Order: U.2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

/**References for this Activity (Full References in Report)
 * Coding Pursuits (2021) - YouTube video used to understand passing data to different activities
 * Coding In Flow (2017) - Used to update the post list automatically
 * KOD Dev (2018) - Tutorial used for adding SQL Records to a Spinner
 * Aman Singh (2016) - Used for reloading the activity after a button click
 */
public class userHome extends AppCompatActivity {

    //XML Object List
    TextView accountID;
    TextView firstname;
    TextView surname;
    ListView postList;

    //Array list used to get posts and display them
    ArrayList<String> listItem;
    ArrayAdapter adapter;

    //used to create a timed auto update
    private BroadcastReceiver updatePostList;

    //Database connections for the posts database and the users database
    dbConnectPosts db = new dbConnectPosts(this);
    dbConnect usersdb = new dbConnect(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        //Sets title
        setTitle("User TimeLine");

        //linking XML Objects
        accountID = findViewById(R.id.accountID);
        firstname = findViewById(R.id.firstnameUserHome);
        surname = findViewById(R.id.surnameUserHome);
        postList = findViewById(R.id.userList);

        //receiving the value passed by the last activity when this one was opened,
        //used to get ID which is used to set account ID and needed for getNames method
        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("UserAccount");
        accountID.setText(receivedValue);

        listItem = new ArrayList<>();
        //Method call to set all the posts on the timeline when activity is opened
        viewData();
        //ID is passed into this function to get the users first and surname
        getNames(receivedValue);

    }

    //opens the users account when My Account button is clicked,
    //passes the usersID into My Account activity
    public void openMyAccount(View view){
        Intent openMyAccount = new Intent(this, myAccount.class);
        openMyAccount.putExtra("UserAccount", accountID.getText().toString());
        startActivity(openMyAccount);
    }

    //opens the createNewPost activity when Create Post button is clicked,
    //passes the usersID into CreateNewPost activity
    public void openCreatePost(View view){
        Intent openCreatePost = new Intent(this, createNewPosts.class);
        openCreatePost.putExtra("UserAccount", accountID.getText().toString());
        startActivity(openCreatePost);
    }

    //opens the MyTimeline activity when My Timeline Button is clicked,
    //passes the usersID into MyTimeline activity
    public void openMyTimeLine(View view){
        Intent openMyTimeLine = new Intent(this, myTimeline.class);
        openMyTimeLine.putExtra("UserAccount", accountID.getText().toString());
        startActivity(openMyTimeLine);
    }

    //finds rows in the post table and sets them onto an Array Adapter to display them within a list view
    public void viewData(){
        //cursor that points to records
        Cursor cursor = db.viewPosts();

        //No posts in the table toast message
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Posts Found",Toast.LENGTH_SHORT).show();
        }
        else {
            //while the cursor finds a record
            while (cursor.moveToNext()){
                //string made up of all columns in post database
                //cursor.getString(i) is used to get specific column
                //then added onto the array list
                String record = "UserName: " + cursor.getString(4) + " " + cursor.getString(5) + "\nPost Date: " + cursor.getString(3)
                        + "\nPost: " + cursor.getString(2) + "\n";
                listItem.add(record);
            }
            //setting adapter layout and content
            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItem);
            postList.setAdapter(adapter);
        }

    }
    //method that refreshes the activity after a tick
    //used to fetch any new posts
    private void startUpdater(){
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        updatePostList = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                /*after tick time elapses then the post list is cleared,
                * post list is fetched again afterwards so new posts are displayed*/
                listItem.clear();
                viewData();
            }
        };
        registerReceiver(updatePostList, intentFilter);
    }

    //on window resume restart updater
    protected void onResume() {
        super.onResume();
        startUpdater();
    }

    //on window pause stop updater, to save on resources
    protected void onPause(){
        super.onPause();
        unregisterReceiver(updatePostList);
    }

    //used to fetch first name and surname, used as welcome back message
    public void getNames(String accountID){
        Cursor cursor = usersdb.fetchUser(accountID);
        //while the cursor has found a record, set value in column 1 as firstname and value in column 2 as surname
        while (cursor.moveToNext()){
            String firstnameRecord = cursor.getString(1);
            String surnameRecord = cursor.getString(2);

            firstname.setText(firstnameRecord);
            surname.setText(surnameRecord);
        }
    }
}